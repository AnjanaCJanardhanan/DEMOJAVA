package com.nissan.method;

public class Rectangle extends Figure{

	public Rectangle(float dim1, float dim2) {
		super(dim1, dim2);
		// TODO Auto-generated constructor stub
	}
	
	public float area(){
		return dim1*dim2;
	}
	
	
	

}
