package com.nissan.method;

public class Shape {
	
	public double area(){
		return 0;
	}

}
