package com.nissan.method;

public class Figure {
	
	float dim1,dim2;

	public Figure(float dim1, float dim2) {
		super();
		this.dim1 = dim1;
		this.dim2 = dim2;
	}
	
	public float area(){
		return 0;
	}

}
